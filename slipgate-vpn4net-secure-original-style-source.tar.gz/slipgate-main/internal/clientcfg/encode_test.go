package clientcfg

import (
	"encoding/base64"
	"strings"
	"testing"
)

func TestEncodeProducesExistingVersionOneSecureURI(t *testing.T) {
	var fields [TotalFields]string
	fields[0] = "28"
	fields[1] = "slipstream_ssh"
	fields[2] = "example-profile"
	fields[3] = "vpn.example"
	fields[4] = "198.51.100.20:53:0"
	fields[5] = "0"
	fields[6] = "5000"
	fields[7] = "user"
	fields[8] = "1080"
	fields[9] = "127.0.0.1"
	fields[10] = "1"

	uri := Encode(fields)
	if !strings.HasPrefix(uri, uriScheme) {
		t.Fatalf("unexpected URI prefix: %q", uri)
	}

	envelope, err := base64.StdEncoding.DecodeString(strings.TrimPrefix(uri, uriScheme))
	if err != nil {
		t.Fatalf("decode secure URI: %v", err)
	}
	if len(envelope) < 29 || envelope[0] != envelopeVersion {
		t.Fatal("unexpected version-1 secure envelope")
	}

	decoded, err := Decode(uri)
	if err != nil {
		t.Fatalf("decode URI: %v", err)
	}
	if decoded != fields {
		t.Fatal("decoded fields do not match encoded fields")
	}

	envelope[len(envelope)-1] ^= 0x01
	if _, err := open(envelope); err == nil {
		t.Fatal("tampered secure envelope was accepted")
	}
}
