package clientcfg

import (
	"crypto/aes"
	"crypto/cipher"
	"crypto/rand"
	"encoding/base64"
	"fmt"
	"io"
	"strings"
)

const uriScheme = "vpnfornet://secure/"
const envelopeVersion byte = 1

// configKey is the existing application configuration-envelope key. It is used
// only to keep server-generated links compatible with the unchanged VPN4Net
// Client v3.0.3 and Administrator v3.0.1 import format.
var configKey = [32]byte{
	0x21, 0x4f, 0x05, 0x20, 0x25, 0xb2, 0xf9, 0x49,
	0x60, 0x5a, 0x54, 0x29, 0xec, 0x3d, 0x5f, 0xa8,
	0x0c, 0x20, 0x22, 0xc1, 0x68, 0xad, 0x94, 0x6e,
	0x68, 0x85, 0x2d, 0x44, 0x72, 0x14, 0xdb, 0xd3,
}

// Encode keeps the original profile field serialization, then wraps it in the
// current app-compatible version-1 secure envelope:
// version byte (1) || 12-byte nonce || AES-GCM ciphertext with 16-byte tag.
func Encode(fields [TotalFields]string) string {
	payload := strings.Join(fields[:], "|")
	envelope, err := seal([]byte(payload))
	if err != nil {
		panic(fmt.Sprintf("secure configuration encoding failed: %v", err))
	}
	return uriScheme + base64.StdEncoding.EncodeToString(envelope)
}

// Decode parses an app-compatible vpnfornet://secure/ URI back into fields.
func Decode(uri string) ([TotalFields]string, error) {
	var fields [TotalFields]string

	encoded := strings.TrimPrefix(uri, uriScheme)
	envelope, err := base64.StdEncoding.DecodeString(encoded)
	if err != nil {
		envelope, err = base64.URLEncoding.DecodeString(encoded)
		if err != nil {
			return fields, err
		}
	}

	payload, err := open(envelope)
	if err != nil {
		return fields, err
	}
	parts := strings.Split(string(payload), "|")
	for i := 0; i < len(parts) && i < TotalFields; i++ {
		fields[i] = parts[i]
	}

	return fields, nil
}

func seal(plaintext []byte) ([]byte, error) {
	block, err := aes.NewCipher(configKey[:])
	if err != nil {
		return nil, err
	}
	gcm, err := cipher.NewGCM(block)
	if err != nil {
		return nil, err
	}

	nonce := make([]byte, gcm.NonceSize())
	if _, err := io.ReadFull(rand.Reader, nonce); err != nil {
		return nil, err
	}
	ciphertext := gcm.Seal(nil, nonce, plaintext, nil)
	envelope := make([]byte, 1+len(nonce)+len(ciphertext))
	envelope[0] = envelopeVersion
	copy(envelope[1:], nonce)
	copy(envelope[1+len(nonce):], ciphertext)
	return envelope, nil
}

func open(envelope []byte) ([]byte, error) {
	if len(envelope) < 1+12+16 {
		return nil, fmt.Errorf("secure configuration envelope too short")
	}
	if envelope[0] != envelopeVersion {
		return nil, fmt.Errorf("unsupported secure configuration version")
	}

	block, err := aes.NewCipher(configKey[:])
	if err != nil {
		return nil, err
	}
	gcm, err := cipher.NewGCM(block)
	if err != nil {
		return nil, err
	}
	if len(envelope) < 1+gcm.NonceSize()+gcm.Overhead() {
		return nil, fmt.Errorf("secure configuration envelope too short")
	}
	return gcm.Open(nil, envelope[1:1+gcm.NonceSize()], envelope[1+gcm.NonceSize():], nil)
}
